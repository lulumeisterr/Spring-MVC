package br.com.fiap.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.fiap.spring.dao.OrcamentoDAO;
import br.com.fiap.spring.exception.KeyNotFoundException;
import br.com.fiap.spring.model.Orcamento;

@Controller
@RequestMapping("orcamento")
public class OrcamentoController {

	@Autowired
	private OrcamentoDAO dao;
	
	// Abrindo a pagina
	
	@GetMapping("cadastrar")
	public String abrirFormulario(Orcamento orcamento) {
		return "orcamento/cadastro";
	}
	
	
	// Executando a acao na pagina
	
	@Transactional
	@PostMapping("cadastrar")
	public String processarForm(Orcamento orcamento, RedirectAttributes r) {		
		dao.create(orcamento);
		r.addFlashAttribute("msg", "Or�amento registrado!");
		return "redirect:/orcamento/cadastrar";
	}
	
	//================================================================================
	
	// Listando
	
	@GetMapping("listar")
	public ModelAndView Listar() {
		return new ModelAndView("orcamento/lista").addObject("variavel",dao.list());
	}
	
	//================================================================================
	
	//Pesquisando
	
	@GetMapping("pesquisar")
	public ModelAndView pesquisar(String descricao) {
		return new ModelAndView("orcamento/lista").addObject("variavel",dao.buscarPorDescricao(descricao));
	}
	
	//================================================================================
	
	//Editando Leitura
	@GetMapping("editar/{id}")
	
	public ModelAndView editar(@PathVariable("id") int codigo) {
		return new ModelAndView("orcamento/edicao").addObject("orcamento",dao.read(codigo));
	}
	
	//Editando no botao
	
	@Transactional
	@PostMapping("editar")
	public String processarEdicao(Orcamento orc , RedirectAttributes r) {
		dao.update(orc);
		r.addFlashAttribute("msg","Orc atualizado");
		return "redirect:/orcamento/listar";
	}
	
	//================================================================================
	
	//Removendo
	@Transactional
	@PostMapping("remover")
	public String excluir(int codigo , RedirectAttributes r) {
		
		try {
			dao.delete(codigo);
		}catch(KeyNotFoundException e) {
			e.printStackTrace();
		}
		
		r.addFlashAttribute("msg","Orcamento excluido");
		return "redirect:/orcamento/listar";
	}
	
	
	//Aprovando
	
	

	
}
